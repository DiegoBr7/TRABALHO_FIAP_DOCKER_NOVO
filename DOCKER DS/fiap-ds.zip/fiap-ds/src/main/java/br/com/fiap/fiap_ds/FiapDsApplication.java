package br.com.fiap.fiap_ds;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FiapDsApplication {

	public static void main(String[] args) {
		SpringApplication.run(FiapDsApplication.class, args);
	}

}
